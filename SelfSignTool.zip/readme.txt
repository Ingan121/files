Instructions:
1. Run gencert.bat and follow its instructions to generate a certificate and add it to system certificate storage
2. Run signwizard.bat
3. Click Next, select an executable, click Custom
4. Select from File, change PKCS to X.509, choose ca.cer in the folder of this tool, then choose ca.pvk
5. Enter the password specified when generating the certificate then select sha1
6. Click Next until the dialog ends
7. Enter the password again
8. End